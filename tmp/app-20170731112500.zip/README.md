:warning: *Use of this software is subject to important terms and conditions as set forth in the License file* :warning: 

Five Most Recent Tickets App
====================

The Zendesk Five Most Recent Tickets App provides you with the simple feature of displaying the 5 most recent tickets of a given user on the right hand side of his current ticket. Please send issues to [support@zendesk.com](mailto:support@zendesk.com). Pull requests are welcome.
